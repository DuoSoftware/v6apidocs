<p class="lead">
	<strong>Duoworld</strong> provides access to a feature-rich, easy-to-use development environment. The platform includes a comprehensive set of services for development and fast deployment. Serving as an Application Development Platform as a Service, DuoWorld enables developers to develop and host apps in a portal for public access. Apps developed by other developers are available to buy and integrate with your own apps.
	Providing a Developer Studio for HTML5 application development and a Data Service Layer for development of the back-end of the enterprise applications reduces the time and effort taken to implement a system with multi-tenancy.
</p>

<hr/>
<h3>Features</h3>
<hr/>
<div class=row>
<div class="col-sm-4">

#### For Business


</div>
<div class="col-sm-4">

#### For Developers


</div>
<!-- <div class="col-sm-4">

#### For Marketing

* 100% Mobile Responsive
* 4 Built-In Themes or roll your own
* Functional, Flat Design Style
* Optional code float layout
* Shareable/Linkable SEO Friendly URLs
* Supports Google Analytics and Piwik Analytics

</div> -->
</div>

<div class="clear"></div>
<hr/>

<!-- Google Code -->
<script type="text/javascript">
var google_conversion_id = 983836026;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
</script>

<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/983836026/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

